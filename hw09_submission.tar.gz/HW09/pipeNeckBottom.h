#ifndef PIPENECKBOTTOM_BITMAP_H
#define PIPENECKBOTTOM_BITMAP_H
extern const unsigned short pipeNeckBottom[312];
#define PIPENECKBOTTOM_WIDTH 26
#define PIPENECKBOTTOM_HEIGHT 12
#endif
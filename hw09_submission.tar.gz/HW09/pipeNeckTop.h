#ifndef PIPENECKTOP_BITMAP_H
#define PIPENECKTOP_BITMAP_H
extern const unsigned short pipeNeckTop[312];
#define PIPENECKTOP_WIDTH 26
#define PIPENECKTOP_HEIGHT 12
#endif
#ifndef GAMEOVERSCREEN_BITMAP_H
#define GAMEOVERSCREEN_BITMAP_H
extern const unsigned short gameoverScreen[38400];
#define GAMEOVERSCREEN_WIDTH 240
#define GAMEOVERSCREEN_HEIGHT 160
#endif
#ifndef PIPEBODY_BITMAP_H
#define PIPEBODY_BITMAP_H
extern const unsigned short pipeBody[24];
#define PIPEBODY_WIDTH 24
#define PIPEBODY_HEIGHT 1
#endif
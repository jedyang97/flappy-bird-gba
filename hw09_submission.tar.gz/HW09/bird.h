#ifndef BIRD_BITMAP_H
#define BIRD_BITMAP_H
extern const unsigned short bird[204];
#define BIRD_WIDTH 17
#define BIRD_HEIGHT 12
#endif
#ifndef BACKGROUND_BITMAP_H
#define BACKGROUND_BITMAP_H
extern const unsigned short background[38400];
#define BACKGROUND_WIDTH 240
#define BACKGROUND_HEIGHT 160
#endif